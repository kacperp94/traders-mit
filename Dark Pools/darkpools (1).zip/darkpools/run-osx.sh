#!/bin/bash
./utils/mangocore-osx-amd64.x --case ./samples/cases/main$1.json --start 5 
