#!/bin/bash

./utils/mangocore-linux-amd64.x --case ./samples/cases/main$1.json --start 5
